package com.ujamang.biz.ui.drawer.codemanager;

public class CodeItem {
    private String code;

    public CodeItem(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
