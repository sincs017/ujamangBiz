package com.ujamang.biz.ui.drawer.notice;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.ujamang.biz.PreferenceManager;
import com.ujamang.biz.R;
import com.ujamang.biz.model.dto.notice.user.NoticeUser;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class NoticeExam extends AppCompatActivity {

    private EditText et_ok;
    private EditText et_totalCount;
    private EditText et_item;
    private EditText et_blank;
    private Button button_test;

    private Context context;
    private NoticeUser noticeUser;

    private SharedPreferences preferences;
    private OkHttpClient client;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_exam);

        et_ok = findViewById(R.id.et_ok);
        et_totalCount = findViewById(R.id.et_totalcount);
        et_item = findViewById(R.id.et_item);
        et_blank = findViewById(R.id.et_blank);
        button_test = findViewById(R.id.button_test);

        preferences = getSharedPreferences("Codemanager", Activity.MODE_PRIVATE); //preferences.getString("authToken", "none");

        client = new OkHttpClient();

        requestAsyncGetHttp();

        /*try {
            run();
        } catch (Exception e) {
            e.printStackTrace();
        }*/

        //String a = preferences.getString("authToken", "none");
        //System.out.println(a);
        //String a = PreferenceManager.getString(context, "authToken").toString();
        //System.out.println(a);

        //System.out.println(PreferenceManager.getString(context, "authToken"));
        //.addHeader("Content-type", "application/json")

        /*new Thread(() -> {
            Gson gson = new Gson();
            OkHttpClient okHttpClient = new OkHttpClient();
            String apiUrl = "http://api.ujamang.biz//api/v1/notice/member/coresoft/2022062000001?p=1&rpp=15&q=";

            Request request = new Request.Builder()
                    .url(apiUrl)
                    .addHeader("Authorization", "bearer " + preferences.getString("authToken", "none"))
                    .build();

            okHttpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    Handler mHandler = new Handler(Looper.getMainLooper());
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            System.out.println("error + Connect Server Error is " + e.toString());
                            //et_ok.setText("Authorization" +" "+ "bearer");
                            et_blank.setText("실패패패");
                        }
                    }, 0);

                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    if (response.isSuccessful()) {
                        ResponseBody responseBody = response.body();
                        noticeUser = gson.fromJson(response.body().string(), NoticeUser.class);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                et_ok.setText(noticeUser.ok ? "성공" : "실패");
                                et_totalCount.setText(noticeUser.totalCount);
                                et_item.setText(noticeUser.item.toString());
                                et_blank.setText("성공공공");
                            }
                        });
                    }
                }
            });
        }).start();*/

        /*button_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://api.ujamang.biz//api/v1/notice/member/coresoft/2022062000001?p=1&rpp=15&q=";
                get(url);
            }
        });*/
    }

    /** ========= [GET 방식 비동기 HTTP 요청 - 쿼리 파라미터 전송 : okhttp document 공식문서] ========= **/
    public void run() throws Exception  {
        Request request = new Request.Builder()
                .url("http://api.ujamang.biz//api/v1/notice/member/coresoft/2022062000001?p=1&rpp=15&q=")
                .addHeader("Authorization", "bearer " + preferences.getString("authToken", "none"))
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                et_blank.setText("실패패패");
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                try (ResponseBody responseBody = response.body()){
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                    Headers responseHeaders = response.headers();
                    for (int i=0, size = responseHeaders.size(); i < size; i++){
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }

                    System.out.println(responseBody.string());
                }

            }
        });
    }


    /** ========= [GET 방식 비동기 HTTP 요청 - 쿼리 파라미터 전송 : 구글링 블로그] ========= **/
    public void requestAsyncGetHttp(){
        try {
            //TODO [Gson 선언]
            Gson gson = new Gson();

            //TODO [전송 url 정의 실시]
            String url = "http://api.ujamang.biz//api/v1/notice/member/coresoft/2022062000001";

            //TODO [파라미터값 선언 실시]
            Map params = new HashMap();
            params.put("p",1);
            params.put("rpp",15);
            params.put("q", "");

            //TODO [url에 파라미터 추가 실시]
            HttpUrl.Builder httpBuilder = HttpUrl.get(url).newBuilder();
            Set set = params.keySet();
            Iterator iterator = set.iterator();
            while(iterator.hasNext()){
                String key = (String) iterator.next();
                httpBuilder.addQueryParameter(key, String.valueOf(params.get(key))); //TODO [쿼리 파람 추가]
            }

            //TODO [OK HTTP 객체 선언 실시]
            OkHttpClient client = new OkHttpClient();
            Request.Builder request = new Request.Builder();
            request.addHeader("Authorization", "Bearer " + preferences.getString("authToken", "none"));
            request.url(httpBuilder.build()); //TODO [httpBuilder 추가]

            Log.d("", preferences.getString("authToken", "none"));
            String a = preferences.getString("authToken", "none");
            System.out.println(a);

            Log.d("---","---");
            Log.d("//===========//","================================================");
            Log.d("","\n"+"[A_OkHttp > requestAsyncGetHttp() 메소드 : OK HTTP 비동기 GET 요청 실시]");
            Log.d("","\n"+"["+"요청 주소 : " + String.valueOf(url)+"]");
            Log.d("","\n"+"["+"전송 값 : " + String.valueOf(params.toString())+"]");
            Log.d("","\n"+"["+"전송 형태 : " + String.valueOf(httpBuilder.build())+"]");
            Log.d("//===========//","================================================");
            Log.d("---","---");

            //TODO [비동기 처리 (enqueue 사용)]
            client.newCall(request.build()).enqueue(new Callback() {
                //TODO [성공한 경우]
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    final String responseCode = String.valueOf(response.toString());
                    final String responseData = response.body().string();
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Log.d("---","---");
                            Log.w("//===========//","================================================");
                            Log.d("","\n"+"[A_OkHttp > requestAsyncGetHttp() 메소드 : OK HTTP 비동기 GET 요청 성공]");
                            Log.d("","\n"+"["+"응답 코드 : " + String.valueOf(responseCode)+"]");
                            Log.d("","\n"+"["+"응답 값 : " + String.valueOf(responseData)+"]");
                            Log.w("//===========//","================================================");
                            Log.d("---","---");

                            //et_ok.setText(noticeUser.ok ? "성공" : "실패");
                            //et_totalCount.setText(noticeUser.totalCount);
                            //et_item.setText(noticeUser.item.toString());
                            //et_blank.setText("성공공공");
                        }
                    });
                }
                //TODO [실패한 경우]
                @Override
                public void onFailure(Call call, IOException e) {
                    final String responseCode = String.valueOf(e.toString());
                    final String responseData = String.valueOf(e.getMessage());
                    runOnUiThread(new Runnable() {
                        public void run() {
                            et_blank.setText("실패패패");
                            Log.d("---","---");
                            Log.e("//===========//","================================================");
                            Log.d("","\n"+"[A_OkHttp > requestAsyncGetHttp() 메소드 : OK HTTP 비동기 GET 요청 실패]");
                            Log.d("","\n"+"["+"에러 코드 : " + String.valueOf(responseCode)+"]");
                            Log.d("","\n"+"["+"에러 값 : " + String.valueOf(responseData)+"]");
                            Log.e("//===========//","================================================");
                            Log.d("---","---");
                        }
                    });
                }
            });
        } catch (final Exception e){
            runOnUiThread(new Runnable() {
                public void run() {
                    Log.d("---","---");
                    Log.e("//===========//","================================================");
                    Log.d("","\n"+"[A_OkHttp > requestAsyncGetHttp() 메소드 : OK HTTP 비동기 GET 요청 실패 - CATCH]");
                    Log.d("","\n"+"["+"에러 값 : " + String.valueOf(e.getMessage())+"]");
                    Log.e("//===========//","================================================");
                    Log.d("---","---");
                }
            });
            e.printStackTrace();
        }
    }
    //잠만
    /*public void get(String requestURL)  {
        try {
            Gson gson = new Gson();
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .addHeader("Content-type", "application/json")
                    .addHeader("Authorization", "bearer " + preferences.getString("authToken", "none"))
                    .url(requestURL)
                    .build();

            //비동기 처리 (enqueue 사용)
            client.newCall(request).enqueue(new Callback() {
                //비동기 처리를 위해 Callback 구현
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    System.out.println("error + Connect Server Error is " + e.toString());
                    *//*et_ok.setText("1");
                    et_totalCount.setText("2");
                    et_item.setText("3");
                    et_blank.setText("4");*//*
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    if (response.isSuccessful()) {
                        ResponseBody responseBody = response.body();
                        noticeUser = gson.fromJson(response.body().string(), NoticeUser.class);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                et_ok.setText(noticeUser.ok ? "성공" : "실패");
                                et_totalCount.setText(noticeUser.totalCount);
                                et_item.setText(noticeUser.item.toString());
                                et_blank.setText("성공공공");
                            }
                        });
                    }


                    *//*ResponseBody responseBody = response.body();
                    System.out.println("Response Body is " + responseBody.string());
                    PreferenceManager.setString(context, "notice_ok", responseBody.);
                    textView1.setText(response.body().string());*//*
                }
            });
        } catch (Exception e) {
            System.err.println(e.toString());
        }
    }*/
}