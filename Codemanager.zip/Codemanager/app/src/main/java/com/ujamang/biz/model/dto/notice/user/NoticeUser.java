package com.ujamang.biz.model.dto.notice.user;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import lombok.Getter;

public abstract class NoticeUser {
    @Getter
    @Expose
    @SerializedName("item")
    public List<Item> item;
    @Expose
    @SerializedName("totalCount")
    public int totalCount;
    @Expose
    @SerializedName("ok")
    public boolean ok;

    public static class Item {
        @Expose
        @SerializedName("registerDate")
        public String registerDate;
        @Expose
        @SerializedName("hits")
        public int hits;
        @Expose
        @SerializedName("title")
        public String title;
        @Expose
        @SerializedName("idx")
        public int idx;
    }
}
