package com.ujamang.biz.ui.drawer.notice;

public class NoticeUjamangAdapter {
}
