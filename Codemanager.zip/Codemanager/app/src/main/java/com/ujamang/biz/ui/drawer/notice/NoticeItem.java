package com.ujamang.biz.ui.drawer.notice;

public class NoticeItem {
    private String notice;

    public NoticeItem(String notice) {
        this.notice = notice;
    }

    public String getNotice() {
        return notice;
    }

    public void setNotice(String notice) {
        this.notice = notice;
    }
}
