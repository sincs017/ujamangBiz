package com.ujamang.biz;

import android.content.SharedPreferences;

public class AutoLogin {

    public static class isChecked{
        //자동로그인을 할 수 있는 사람인지 체크하고 맞으면 메인화면으로 넘어가고, 아니면 로그인을 진행해야한다.

    }
}
